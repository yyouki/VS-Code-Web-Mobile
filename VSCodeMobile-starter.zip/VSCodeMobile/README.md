# VS Code Mobile — Android WebView prototype

Starter source project for an Android app that opens `https://vscode.dev/` in a WebView and adds a two-row coding toolbar.

## Included

- Kotlin Activity with Android WebView.
- Extra keys: CTRL, ALT, SHIFT, ESC, TAB, F1, F5, P, C, V, X, arrows, HOME, END, DEL.
- Common programming symbols: `{ } [ ] ( ) ; : / \\ | ~ _`.
- CTRL/ALT/SHIFT apply to the next toolbar key. Example: tap CTRL, SHIFT, then the toolbar P key for Ctrl+Shift+P. They do not currently modify keys typed through the Android software keyboard.
- No JavaScript bridge is exposed to the remote website.

## Build notes

This archive is a starter project, not an APK. It has not been compiled or tested on a physical Android device in this environment because an Android SDK and Gradle installation are not available here.

The Gradle wrapper properties specify Gradle 9.5.0, but the wrapper launch scripts and wrapper JAR are not bundled. To build, use an Android Studio installation with a local Gradle 9.5.0 setup, or generate the standard wrapper from the project root with:

```bash
gradle wrapper --gradle-version 9.5.0
```

Then install Android SDK Platform 36, open the project in Android Studio, sync Gradle, connect an Android device (or start an emulator), and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. A debug APK is normally written to `app/build/outputs/apk/debug/`.

## Prototype limitations

- VS Code for the Web has browser-based limitations: the full desktop terminal/debugger and some extensions are unavailable.
- WebView keyboard routing can vary by Android System WebView version and editor focus state. Verify each shortcut on the target phone; some key combinations may need platform-specific handling.
- Local folder access, file upload/download handling, desktop-style tabs, and external authentication refinements are not included yet.
- `vscode.dev` is a remote service; internet access is required.
